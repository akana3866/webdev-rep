<?php

  // define your file path here
  $path = getcwd() . '/databases';

 ?>
