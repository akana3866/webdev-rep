  <style>
    #navigation {
        align-items: left;
        padding: 10px;
        color: #fff;
        text-align: left;
    }

    #navigation a {
        display: inline-block;
        padding: 8px 16px;
        margin-right: 10px;
        border: none;
        border-radius: 4px;
        background-color: #4CAF50;
        color: #fff;
        font-size: 16px;
        text-decoration: none;
        cursor: pointer;
    }

    #navigation a:hover {
        background-color: #3e8e41;
    }
</style>
     
        <div id="navigation">
            <a href="index.php">View All Movies!</a>
            <a href="add_form.php">Add a Movie!</a>
            <a href="search_form.php">Search for a Movie!</a>
        </div>
